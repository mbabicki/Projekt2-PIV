﻿namespace DemoMauiBookDatabase.Models
{
    public class Error
    {
        public string Property { get; set; }
        public string Value { get; set; }
    }
}
